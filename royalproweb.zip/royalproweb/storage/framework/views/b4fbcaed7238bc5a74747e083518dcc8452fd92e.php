<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>Update Data Nasabah</title>
    </head>
    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    CRUD Data Nasabah - <strong>Edit Data</strong> - <a href="www.axa-financial.co.id" target="_blank">www.axa-financial.co.id</a>
                </div>
                <div class="card-body">
                    <a href="/nasabah" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
                    
 
                    <form method="post" action="/nasabah/update/<?php echo e($nasabah->id); ?>">
 
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

 
                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="nama" class="form-control" placeholder="Nama nasabah ..." value=" <?php echo e($nasabah->nama); ?>">
 
                            <?php if($errors->has('nama')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('nama')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
 
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea name="alamat" class="form-control" placeholder="Alamat nasabah ..."> <?php echo e($nasabah->alamat); ?> </textarea>
 
                             <?php if($errors->has('alamat')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('alamat')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
 
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
 
                    </form>
 
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\royalproweb\resources\views/nasabah_edit.blade.php ENDPATH**/ ?>