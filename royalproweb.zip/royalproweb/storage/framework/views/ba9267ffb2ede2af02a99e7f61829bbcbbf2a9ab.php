<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>Data Nasabah Royal Prodigy</title>
        <style>
            .jarak{
                margin-bottom: 50px;
                margin-left: 120px
            }
            .batas{
                margin-top: 30px;
                margin-left: 120px
            }
            .rata{
                margin-top: 5px;
                margin-left: 120px;
                margin-bottom: 5px
            }
        </style>
    </head>
    <body>
        <div class="batas">
            <img src="img/logo axa.png"  width="200px" height="200px">
        </div>
        <h1 class="rata">AXA Financial</h1>
        <h2 class="rata">Royal Prodigy Team</h2>
        <h7 class="rata">Data Bank Nama Calon Nasabah</h7>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    CRUD Data Nasabah - <a href="https://www.axa-financial.co.id" target="_blank">www.axa-financial.co.id</a>
                </div>
                <div class="card-body">
                    <a href="/nasabah/tambah" class="btn btn-primary">Input Nasabah Baru</a>
                    <br/>
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>NIK</th>
                                <th>Nama</th>
                                <th>Pekerjaan</th>
                                <th>Alamat</th>
                                <th>OPSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $nasabah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($n->nik); ?></td>
                                <td><?php echo e($n->nama); ?></td>
                                <td><?php echo e($n->pekerjaan); ?></td>
                                <td><?php echo e($n->alamat); ?></td>
                                <td>
                                    <a href="/nasabah/edit/<?php echo e($n->id); ?>" class="btn btn-warning">Edit</a>
                                    <a href="/nasabah/hapus/<?php echo e($n->id); ?>" class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <style type="text/css">
            .pagination li{
                float: left;
                list-style-type: none;
                margin:5px;
            }
        </style>
        <br/>
        <div class="jarak">
            Halaman : <?php echo e($nasabah->currentPage()); ?> <br/>
            Jumlah Data : <?php echo e($nasabah->total()); ?> <br/>
            Data per Halaman : <?php echo e($nasabah->perPage()); ?>


            <?php echo e($nasabah->links()); ?>

        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\royalproweb\resources\views/nasabah.blade.php ENDPATH**/ ?>